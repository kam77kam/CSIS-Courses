/*
Assignment: Final Code CSIS 1400
Name: Kamdon Bird
Date: 12/10/18
*/
public enum Direction{
   UP, DOWN, LEFT, RIGHT
}