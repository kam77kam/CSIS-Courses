package labFile;

public class MountainApp {
	public static void main(String[] args) {
		
	}
}
