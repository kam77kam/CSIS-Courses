public class EagleApp {
   public static void main(String[] args){
      Eagle myEagle = new Eagle(8);
      myEagle.catchMouse();
      getcatchMouse;
      System.out.print("mouseCount: " + );
   }
}