import java.util.Scanner;

public class ifApp {

   public static void main(String[] args){
      Scanner n1 = new Scanner(System.in);
      System.out.println("Print an integer: ");
      Scanner n2 = new Scanner(System.in);
      System.out.println("Print an integer: ");
      Scanner n3 = new Scanner(System.in);
      System.out.println("Print an integer: ");
      
   }
}