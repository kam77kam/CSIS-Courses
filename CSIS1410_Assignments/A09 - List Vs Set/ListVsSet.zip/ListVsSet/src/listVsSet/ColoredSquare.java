package listVsSet;

public class ColoredSquare {

}
